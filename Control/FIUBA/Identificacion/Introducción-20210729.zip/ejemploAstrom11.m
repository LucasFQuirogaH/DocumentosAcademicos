%ejemplo 11
g1=zpk([],[-1 .01],1)
g2=zpk([],[-1 0],1)
g3=zpk([],[-1 -.01],1)
step(g1,g2,g3,100);grid
glc1=g1/(1+g1)
glc2=g2/(1+g2)
glc3=g3/(1+g3)
step(glc1,glc2,glc3,10);grid
bode(g1,g2,g3);grid
bode(glc1,glc2,glc3);grid

%ejemplo 12
g=zpk([],[-1 -20],400)
g1=g*(tf([-0.00001 1],[0.00001 1]))
g2=g*(tf([-.015 1],[.015 1]))
g3=g*(tf([-.03 1],[.03 1]))
step(g1,g2,g3,5);grid
k=.1
glc1=k*g1/(1+k*g1)
glc2=k*g2/(1+k*g2)
glc3=k*g3/(1+k*g3)
step(glc1,glc2,glc3,1);grid
bode(g1,g2,g3);grid
bode(glc1,glc2,glc3);grid
