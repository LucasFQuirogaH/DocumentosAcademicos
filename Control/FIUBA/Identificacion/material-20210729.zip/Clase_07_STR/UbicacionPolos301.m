%% Control Adaptativo
% Motor
% ejemplo 3.1 del libro de control adaptativo de Astrom
% motor con cancelaci�n de ceros
% puede no ser adaptativo
%%
n=150;
Ts=.5;

%%
%Motor. Sistema continuo
% Entradas: torque motor y torque resistente
s=tf('s');
z=tf('z',Ts);
K = 1;
tau = 1;
G= K/s/(tau*s+1);
% el sistema tiene dos entradas
GT=[1 1]*G;
% Sistema Continuo en Variables de Estado
SC=ss(GT);

sr=.0; %ruido

% Sistema discretizado
GTD=c2d(GT,Ts);
GTD.Variable='z^-1';
Bd=GTD(1,1).num{1};
Ad=GTD(1,1).den{1};
GTD
%%
%
%  Respuesta al Impulso
%
impulse(SC,6);grid;legend('motor');

%%
%
%  Modelo Deseado
%
% modelo de seguimiento de referencias
pmr=.6;
Amr=poly([pmr pmr]);
p1=Amr(2);
p2=Amr(3);
bm0=sum(Amr);
Bmr=[0 0 bm0];
Gmr=tf(Bmr,Amr,Ts);
Gmr.Variable='z^-1';
Gmr
%%
%
%  Modelo Deseado
% modelo de correcci�n de perturbaciones
plc=.3;
Alc=poly([plc plc]);
alc1=Alc(2);
alc2=Alc(3);
Alc
%%
prec=Ts/10;
t=[0:prec:Ts];
yc=zeros(size(t));
uu=[];
yy=[];
vv=[];
yym=[];
tt=[];

%%
x=zeros(2,length(SC.a));
lx=length(SC.a);
y=zeros(n,1);
yd=zeros(n,1);
u=zeros(n,1);
r=zeros(n,1);
rf=zeros(n,1);
ym=zeros(n,1);

%%
% Ubicaci�n de Polos
Amas=1;
Amenos=Ad;
Bmas=[1 -roots(Bd)];
Bmenos=deconv(Bd,Bmas);

% C�lculo de Rr y Sr
NA = numel(Amenos) ;
NB = numel(Bmenos) ;
% crea la Matriz de Sylvester
MA = toeplitz2([Amenos ; zeros(NA-3,1)],zeros(NA-2,1));
MB = toeplitz2([Bmenos'; zeros(NB-1,1)],zeros(NB,1));
M = [MA MB];
RS=inv(M)*Alc';
Rr=RS(1)';
Sr=RS(2:3)';
% verificaci�n
ARBSr=conv(Amenos,Rr)+conv(Bmenos,Sr)
roots(ARBSr)

%%
% C�lculo de R y S
%
% R=Amr.Bmas.Rr
% S=Amr.Amas.Rr
R=conv(conv(Rr,Amr),Bmas);
S=conv(conv(Sr,Amr),Amas);
lr=length(R);
ls=length(S);
% verificaci�n
ar=conv(R,Ad);
bs=conv(S,Bd);
%bs=[aa(2:end) 0];
ARBS=ar+bs;
roots(ARBS)

%%
% C�lculo de T
%
% T=Bmr.Alc.Amas.t0
% t0 es la ganancia est�tica
T=conv(conv(Alc,Amas),Bmr)
t0=sum(ARBS)/sum(Bd)/sum(T);
T=t0*T;
%T=[0 0 .7359 0 0];
%%
% Verificaci�n el LC
% La ft a lc debe contener los polos de Amr y de Alc
% no debe contener los ceros cancelados con Bmas
Rtf=filt(R,1,Ts);
Stf=filt(S,1,Ts);
Ttf=filt(T,1,Ts)*z^2;

GLC=zpk(minreal(Ttf*GTD(1,1)/(Rtf+GTD(1,1)*Stf)))

BB=filt(GTD(1,1).num{1},1,Ts);
AA=filt(GTD(1,1).den{1},1,Ts);


%%
% Controlador
%
% R.u= T.r-S.y
Cont=[Ttf/Rtf Stf/Rtf];
Contss=ss(Cont);
xc=zeros(2,length(Contss.a));
lxc=length(Contss.a);

%%
pplantaR=[Bd Ad];


%%
% Simulaci�n sin adaptaci�n
% inicializaci�n identificaci�n
na=2;
nb=2;
np=na+nb;
Aest = .3*ones(n,np);
Areal = [-Ad(2)*ones(n,1) -Ad(3)*ones(n,1) Bd(1)*ones(n,1) Bd(2)*ones(n,1)];
ParEst = zeros(np,1);
lam=1;
p=10000*eye(np);
th=eps*ones(np,1);
xa = zeros(np,1);
gan = zeros(n,1); %para verificar la ganancia estatica

vc=zeros(size(t))';

for i=5:n
    %c�lculo de la referencia
    r(i)=1;
    if i>n*2/3; r(i)=-1;end;
    
    % Muestreo de la salida
    y(i)=yc(length(yc));
    
    % Identificacion
    xa=[flipud(y(i-na:i-1)); flipud(u(i-nb:i-1))];
    yh=xa'*Aest(i-1,1:np)';
    epsi=y(i)-yh;
    Ka=p*xa/(lam + xa'*p*xa);
    p=(p-Ka*xa'*p)/lam;
    Aest(i,1:np)=(Aest(i-1,1:np)'+Ka*epsi)';
    
    %    gan(i)=t0/(s0+s1);
   % gan(i)=sum(Bd)/(sum(R)*sum(Ad)+sum(Bd)*sum(S))*(sum(T)*abs(r(i))+vc(1));
    gan(i)=sum(Bd)/(sum(R)*sum(Ad)+sum(Bd)*sum(S))*(sum(T)*abs(r(i))+sum(R)*vc(1));
   
    %c�lculo de la accion de control
    [uss,ttttt,xc]=lsim(Contss,[r(i-1:i) -y(i-1:i)],[0 Ts],xc(2,:));
    u(i)=uss(2);
    
    % bloqueador actuaci�n
    uc=(u(i)+sr*randn)*ones(size(t))';
    %Perturbaci�n
    vc=zeros(size(t))';
    if i>n/3
        vc=-.2*ones(size(t))';
    end
    %sistema continuo
    [yc,ts,x]=lsim(SC,[uc vc],t,x(length(x),:));
    uu=[uu; uc(2:length(uc))];
    yy=[yy; yc(2:length(yc))];
    vv=[vv; vc(2:length(yc))];
    
    % modelo de referencia
    ym(i)=-Amr(2)*ym(i-1)-Amr(3)*ym(i-2)+r(i-1)*(1+p1+p2);
    yym=[yym; (ym(i)*ones(length(uc)-1))'];
end
%%
%
%  Sistema
%
plot([uu yy yym]);grid;;legend('acci�n de control','salida','modelo','Location','SouthWest');
axis([1 length(uu) -1.5 2.5])
title('u, y, ym. caso no adaptativo');
%%
%
% Par�metros Estimados
%
plot([Aest Areal]);grid; title('Par�metros estimados. caso no adaptativo');
%%
%
% Ganancia Est�tica
%
plot(gan(5:end));grid; title('Ganancia est�tica. caso no adaptativo');

%%
% Simulaci�n con adaptaci�n

%%
prec=Ts/10;
t=[0:prec:Ts];
yc=zeros(size(t));
uu=[];
yy=[];
vv=[];
yym=[];
tt=[];

% K=exp(-T)-1+T;
% a=exp(-T);
% b=1-T*(1-exp(-T))/(exp(-T)-1+T);
x=zeros(2,2);

y=zeros(n,1);
yd=zeros(n,1);
u=zeros(n,1);
r=zeros(n,1);
rf=zeros(n,1);
ym=zeros(n,1);
PRegE=zeros(n,9);

% inicializaci�n identificaci�n
Aest = .3*ones(n,np);
ParEst = zeros(np,1);
p=10000*eye(np);
th=eps*ones(np,1);
xa = zeros(np,1);
gan = zeros(n,1); %para verificar la ganancia estatica

vc=zeros(size(t))';
for i=4:n
    %c�lculo de la referencia
    r(i)=1;
    if i>n*2/3; r(i)=-1;end;
    % Muestreo de la salida
    
    y(i)=yc(length(yc));
    
    % Identificacion
    xa=[flipud(y(i-na:i-1)); flipud(u(i-nb:i-1))];
    yh=xa'*Aest(i-1,1:np)';
    epsi=y(i)-yh;
    Ka=p*xa/(lam + xa'*p*xa);
    p=(p-Ka*xa'*p)/lam;
    Aest(i,1:np)=(Aest(i-1,1:np)'+Ka*epsi)';
    
    % calculo de los parametros del regulador
    % Ubicaci�n de Polos
    Ade=[1 -Aest(i,1:2)];
    Bde=[0 Aest(i,3:4)];
    Amas=1;
    Amenos=Ade;
    Bmas=[1 -roots(Bde)];
    Bmenos=deconv(Bde,Bmas);
    
    % C�lculo de Rr y Sr
    NA = numel(Amenos) ;
    NB = numel(Bmenos) ;
    % crea la Matriz de Sylvester
    MA = toeplitz2([Amenos ; zeros(NA-3,1)],zeros(NA-2,1));
    MB = toeplitz2([Bmenos'; zeros(NB-1,1)],zeros(NB,1));
    M = [MA MB];
    RS=inv(M)*Alc';
    Rr=RS(1)';
    Sr=RS(2:3)';
    % C�lculo de R y S
    %
    % R=Amr.Bmas.Rr
    % S=Amr.Amas.Rr
    Re=conv(conv(Rr,Amr),Bmas);
    Se=conv(conv(Sr,Amr),Amas);
    lr=length(Re);
    ls=length(Se);
    % verificaci�n
    ar=conv(Re,Ade);
    bs=conv(Se,Bde);
    ARBSe=ar+bs;
    % C�lculo de T
    %
    % T=Bmr.Alc.Amas.t0
    % t0 es la ganancia est�tica
    Te=conv(conv(Alc,Amas),Bmr);
    t0e=sum(ARBSe)/sum(Bde)/sum(Te);
    Te=t0e*Te;
    
    %Ganancia est�tica
    %gan(i)=sum(Bd)/(sum(Re)*sum(Ad)+sum(Bd)*sum(Se))*(sum(Te)*abs(r(i))+vc(1));
    gan(i)=sum(Bde)/(sum(Re)*sum(Ade)+sum(Bde)*sum(Se))*(sum(Te)*abs(r(i))+sum(Re)*vc(1));
    % guardo los par�metros del regulador
    PRegE(i,:)=[t0e Se Re];
    
    %c�lculo de la accion de control
    u(i)=sum(Te)*r(i)-Se*flipud(y(i-ls+1:i))-Re(2:lr)*flipud(u(i-lr+1:i-1));
    % bloqueador actuaci�n
    uc=(u(i)+sr*randn)*ones(size(t))';
    %Perturbaci�n
    vc=zeros(size(t))';
    if i>n/3
        vc=-.2*ones(size(t))';
    end
    %sistema continuo
    [yc,ts,x]=lsim(SC,[uc vc],t,x(length(x),:));
    uu=[uu; uc(2:length(uc))];
    yy=[yy; yc(2:length(yc))];
    vv=[vv; vc(2:length(yc))];
    
    % modelo de referencia
    ym(i)=-Amr(2)*ym(i-1)-Amr(3)*ym(i-2)+r(i-1)*(1+p1+p2);
    yym=[yym; (ym(i)*ones(length(uc)-1))'];
end
%%
%
%  Sistema
%
plot([uu yy yym]);grid;;legend('acci�n de control','salida','modelo','Location','NorthWest');
axis([1 length(uu) -1.5 2.5])
title('u, y, ym. caso adaptativo');
%%
%
% Par�metros Estimados
%
plot([Aest Areal]);grid; title('Par�metros estimados. caso adaptativo');
%%
%
% Ganancia Est�tica
%
plot(gan(5:end));grid; title('Ganancia est�tica. caso adaptativo');
axis([1 length(gan) 0.7 1.05])
%%
% Polos y Ceros Estimados de la Planta y del Controlador
Areal = [-Ad(2)*ones(n,1) -Ad(3)*ones(n,1) Bd(2)*ones(n,1) Bd(3)*ones(n,1)];
Ae=[ones(n,1) -Aest(:,1:2)]; % A estimado
Be=[Aest(:,3:4)];% B estimado
%pregR=[t0 S R];
%pplantaR=[Bd Ad];
%preg(i,:)=[t0 S R];

ppe=[]; %polos de la planta estimados
cpe=[]; %ceros de la planta estimados
pcrege=[];% polos y ceros del regulador estimados
% par�metros del regulador reales en forma de vector
PReg=[t0*ones(n,1) S(1)*ones(n,1) S(2)*ones(n,1) S(3)*ones(n,1) S(4)*ones(n,1) R(1)*ones(n,1) R(2)*ones(n,1) R(3)*ones(n,1) R(4)*ones(n,1)];
pcregr=[];% polos y ceros del regulador reales
ppr=[];% polos de la planta reales
cpr=[];% ceros de la planta reales
for i=4:n
    ppe(i,:)=roots(Ae(i,:));
    cpe(i,:)=roots(Be(i,:));
    pcreg(i,:)=[roots(preg(i,2:5))' roots(preg(i,6:9))'];
    ppr(i,:)=roots([1 -Areal(i,1:2)]);
    cpr(i,:)=roots(Areal(i,3:4));
    pcreg(i,:)=[roots(PReg(i,2:5))' roots(PReg(i,6:9))'];
end
Se=preg(90,2:5);
Re=preg(90,6:9);
Ade=[1 -Aest(90,1:2)];
Bde=[Aest(90,3:4)];
ARBSE=conv(Ade,Re)+[0 conv(Bde,Se)];
roots(ARBSE);
%%
break

%%
%
% Polos y Ceros del regulador, Reales y Estimados
%
plot(abs([pcreg pcrege]));grid; title('Polos y Ceros del regulador, reales y estimados');
axis([1 n 0 1])
%%
%
% Polos y Ceros de la Planta
%
plot(abs([ppr cpr ppe cpe]));grid; title('Polos y Ceros de la Planta, reales y estimados');
axis([1 n 0 1.5])
%%
%
% Polos y Ceros de la Planta
%
plot(abs([pcregr pcrege ppr cpr ppe cpe]));grid; title('Polos y Ceros de la Planta y Regulador, reales y estimados');
axis([1 n 0 1.2])


