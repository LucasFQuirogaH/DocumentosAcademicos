%% Control Adaptativo Directo
% Motor
% ejemplo 3.7 del libro de control adaptativo de Astrom
% motor con cancelaci�n de ceros
% puede no ser adaptativo
% Se retoma el ejemplo 3.1 y se hace directo
% Variando d0, permite cancelar o no el cero de la planta. 
% Con d0=1 le quita el ringing (ej. 3.8) porque no cancela el cero

%%
n=150;
Ts=.5;

%%
%Motor. Sistema continuo
% Entradas: torque motor y torque resistente
s=tf('s');
z=tf('z',Ts);
K = 1;
tau = 1;
G= K/s/(tau*s+1);
% el sistema tiene dos entradas
GT=[1 1]*G;
% Sistema Continuo en Variables de Estado
SC=ss(GT);

sr=.0; %ruido

% Sistema discretizado
GTD=c2d(GT,Ts);
GTD.Variable='z^-1';
Bd=GTD(1,1).num{1};
Ad=GTD(1,1).den{1};
zpk(GTD)
%%
%
%  Respuesta al Impulso
%
impulse(SC,6);grid;legend('motor');

%%
%
%  Modelo Deseado
%
% modelo de seguimiento de referencias
pmr=.6;
Amr=poly([pmr pmr]);
p1=Amr(2);
p2=Amr(3);
bm0=sum(Amr);
Bmr=[0 0 bm0];
Gmr=tf(Bmr,Amr,Ts);
Gmr.Variable='z^-1';
Gmr
%%
%
%  Modelo Deseado
% modelo de correcci�n de perturbaciones
plc=.3;
Alc=poly([plc plc]);
alc1=Alc(2);
alc2=Alc(3);
Alc
%%
prec=Ts/10;
t=[0:prec:Ts];
yc=zeros(size(t));
uu=[];
yy=[];
vv=[];
yym=[];
tt=[];

%%
x=zeros(2,length(SC.a));
lx=length(SC.a);
y=zeros(n,1);
yd=zeros(n,1);
u=zeros(n,1);
r=zeros(n,1);
rf=zeros(n,1);
ym=zeros(n,1);

%%
% Ubicaci�n de Polos
Amas=1;
Amenos=Ad;
Bmas=[1 -roots(Bd)];
Bmenos=deconv(Bd,Bmas); % es b0

% C�lculo de Rr y Sr
NA = numel(Amenos) ;
NB = numel(Bmenos) ;
% crea la Matriz de Sylvester
MA = toeplitz2([Amenos ; zeros(NA-3,1)],zeros(NA-2,1));
MB = toeplitz2([Bmenos'; zeros(NB-1,1)],zeros(NB,1));
M = [MA MB];
RS=inv(M)*Alc';
Rr=RS(1)';
Sr=RS(2:3)';
% verificaci�n
ARBSr=conv(Amenos,Rr)+conv(Bmenos,Sr)
roots(ARBSr)

%%
% C�lculo de R y S
%
% R=Amr.Bmas.Rr
% S=Amr.Amas.Rr
R=conv(conv(Rr,Amr),Bmas);
S=conv(conv(Sr,Amr),Amas);

%sacar pero con este controlador anda igual !!!
% R=[0.9996 0.5866 -0.0979 0.0952];
% S=[ 0.5869 0.3727 0.1079 -0.3316];

lr=length(R);
ls=length(S);
% verificaci�n
ar=conv(R,Ad);
bs=conv(S,Bd);
%bs=[aa(2:end) 0];
ARBS=ar+bs;
roots(ARBS)

%%
% C�lculo de T
%
% T=Bmr.Alc.Amas.t0
% t0 es la ganancia est�tica
T=conv(conv(Alc,Amas),Bmr)
t0=sum(ARBS)/sum(Bd)/sum(T);
T=t0*T;
%T=[0 0 .7359 0 0];
%%
% Verificaci�n el LC
% La ft a lc debe contener los polos de Amr y de Alc
% no debe contener los ceros cancelados con Bmas
Rtf=filt(R,1,Ts);
Stf=filt(S,1,Ts);
Ttf=filt(T,1,Ts)*z^2;

GLC=zpk(minreal(Ttf*GTD(1,1)/(Rtf+GTD(1,1)*Stf)))

BB=filt(GTD(1,1).num{1},1,Ts);
AA=filt(GTD(1,1).den{1},1,Ts);

%%
% Controlador
%
% R.u= T.r-S.y
Cont=[Ttf/Rtf Stf/Rtf];
Contss=ss(Cont);
xc=zeros(2,length(Contss.a));
lxc=length(Contss.a);

%%
pplantaR=[Bd Ad];

%%
% inicializaci�n identificaci�n
nr=4;
ns=4;
np=nr+ns;
Aest = 1.0*ones(n,np);
Areal = [R(1)*ones(n,1) R(2)*ones(n,1) R(3)*ones(n,1) R(4)*ones(n,1) S(1)*ones(n,1) S(2)*ones(n,1) S(3)*ones(n,1) S(4)*ones(n,1)];
ParEst = zeros(np,1);
lam=1;
p=1000*eye(np);
th=eps*ones(np,1);
xa = zeros(np,1);
gan = zeros(n,1); %para verificar la ganancia estatica

vc=zeros(size(t))';
%%
% Filtro para estimar R y S
Alcm=conv(Alc,Amr);
lf=length(Alcm);
uf=zeros(n,1);
yf=zeros(n,1);
yh=zeros(n,1);

%% Caso 1 d0=0. Cancelaci�n de cero
%
d0=0; %anda con 0 y 1
% solo usados para depurar
%yff=zeros(n,1);
%uff=zeros(n,1);
%yfff=zeros(n,1);
for i=6:n
    %c�lculo de la referencia
    r(i)=1;
    if i>n*2/3; r(i)=-1;end;
    
    % Muestreo de la salida
    y(i)=yc(length(yc));
    
    % Identificacion
    % se�ales filtradas
    uf(i)=-Alcm(2:lf)*flipud(uf(i-lf+1:i-1))+1*u(i-1);
    yf(i)=-Alcm(2:lf)*flipud(yf(i-lf+1:i-1))+1*y(i-1);
    
    xa=[flipud(uf(i-d0-3:i-d0)); flipud(yf(i-d0-3:i-d0))];
    yh(i)=xa'*Aest(i-1,1:np)';
    epsi=y(i)-yh(i);
    Ka=p*xa/(lam + xa'*p*xa);
    p=(p-Ka*xa'*p)/lam;
    Aest(i,1:np)=(Aest(i-1,1:np)'+Ka*epsi)';
    
    % calculo de los parametros del regulador
    % Ubicaci�n de Polos
    % divido por b0 estimado 
    b0e=Aest(i,1);
    Re=Aest(i,1:4)/b0e;
    Se=Aest(i,5:8)/b0e;
    lr=length(Re);
    ls=length(Se);
    % verificaci�n
    are=conv(Re,Ad);
    bse=conv(Se,Bd);
    ARBSe=are+bse;
    % C�lculo de T
    %
    % T=Bmr.Alc.Amas.t0
    % t0 es la ganancia est�tica (con esto anda
    t0e=sum(Alcm)/b0e;
    
    %Ganancia est�tica
    %gan(i)=sum(Bd)/(sum(Re)*sum(Ad)+sum(Bd)*sum(Se))*t0e*(abs(r(i)));
    gan(i)=sum(Bde)/(sum(Re)*sum(Ade)+sum(Bde)*sum(Se))*(sum(Te)*abs(r(i))+sum(Re)*vc(1));
    % guardo los par�metros del regulador
    PRegE(i,:)=[t0e Se Re];
    
    %c�lculo de la accion de control
    u(i)=t0e*r(i)-Se*flipud(y(i-ls+1:i))-Re(2:lr)*flipud(u(i-lr+1:i-1));

    % bloqueador actuaci�n
    uc=(u(i)+sr*randn)*ones(size(t))';
    %Perturbaci�n
    vc=zeros(size(t))';
    if i>n/3
        vc=-.2*ones(size(t))';
    end
    %sistema continuo
    [yc,ts,x]=lsim(SC,[uc vc],t,x(length(x),:));
    uu=[uu; uc(2:length(uc))];
    yy=[yy; yc(2:length(yc))];
    vv=[vv; vc(2:length(yc))];
    
    % modelo de referencia
    ym(i)=-Amr(2)*ym(i-1)-Amr(3)*ym(i-2)+r(i-1)*(1+p1+p2);
    yym=[yym; (ym(i)*ones(length(uc)-1))'];
end
%%
%
%  Sistema
%
plot([uu yy yym]);grid;;legend('acci�n de control','salida','modelo','Location','SouthWest');
axis([1 length(uu) -1.5 2.5])
title('u, y, ym. caso adaptativo directo');
%%
%
% Par�metros Estimados
%
plot([Aest Areal]);grid; title('Par�metros estimados. caso adaptativo directo');
axis([1 length(Aest) -2 2])
%%
%
% Ganancia Est�tica
%
plot(gan(5:end));grid; title('Ganancia est�tica. caso adaptativo directo');

break

%%
%
% Polos y Ceros del regulador, Reales y Estimados
%
plot(abs([pcreg pcrege]));grid; title('Polos y Ceros del regulador, reales y estimados');
axis([1 n 0 1])
%%
%
% Polos y Ceros de la Planta
%
plot(abs([ppr cpr ppe cpe]));grid; title('Polos y Ceros de la Planta, reales y estimados');
axis([1 n 0 1.5])
%%
%
% Polos y Ceros de la Planta
%
plot(abs([pcregr pcrege ppr cpr ppe cpe]));grid; title('Polos y Ceros de la Planta y Regulador, reales y estimados');
axis([1 n 0 1.2])


