%% Respuesta Impulsional por Correlaci�n
% 
%% Planta Tanque
s=tf('s');
K=8;
tau=5;
T=.2;
G=K/(tau*s+1)
%%
Gd=c2d(G,T)
m=50*tau;
yi=impulse(Gd,m);
%% Respuesta Impulsional por Correlaci�n
n=100*m;
urb=sign(randn(n,1));
yrb=lsim(Gd,urb);
zrb=[yrb urb];
R=covf(zrb,m+1);
Ryy=[R(1,m:-1:2)';R(1,:)'];
Ruu=[R(4,m:-1:2)';R(4,:)'];
vuu=Ruu(m);
vyu=sqrt(Ryy(m)*vuu);
%r(:,1)=[-m+1:1:m-1]';
Ryu=[R(3,m:-1:2)';R(2,:)']/vyu;
rirb=Ryu(m:2*m-1)*vyu/vuu;
% o m�s simple,
rirb=R(2,:)'/R(4,1);
%% Resultados
plot([yi(1:m) rirb(1:m)]);grid;legend('ri','riirb')

%% Respuesta en Frecuencia con Excitaci�n Ruido Blanco
N=128;
M=[];
nfft = 2^nextpow2(max(n,2*N));
Y=fft(zrb(:,1),nfft);
l=length(Y);
M=length(Y);
M1=1;
sc=l/(2*N);
Yd=Y(M1+fix(M1/2)+sc:sc:M1+fix(M1/2)+l/2);
U=fft(zrb(:,2),nfft);
Ud=U(M1+fix(M1/2)+sc:sc:l/2+M1+fix(M1/2));
g(1:N,1)=(1:N)'*pi/N/T;
g(1:N,2)=20*log10(abs(Yd./Ud));
g(1:N,3)=-180*phase((Yd./Ud)')'/pi;
%sis=Gd;

w=(1:N)'*pi/N/T;
rm=20*log10(abs(Yd./Ud));
f=-180*phase((Yd./Ud)')'/pi;

%% 
% Bode
[rmbode,fbode,wb] = bode(Gd);
for i=1:length(rmbode)
    rmb(i)=20*log10(rmbode(1,1,i));
    fb(i)=fbode(1,1,i);
end
%% Resultados
subplot(2,1,1);
semilogx(w,rm,wb,rmb);
grid;legend('ri','riirb')
axis([.01 10 -20 30]);
subplot(2,1,2);
semilogx(w,f,wb,fb);
grid;legend('ri','riirb')
axis([.01 10 -300 0]);

%% Respuesta en Frecuencia con Excitaci�n Ruido Blanco
% Correlaci�n
N=128;
M=[];
nfft = 2^nextpow2(max(n,2*N));
YC=100*fft(rirb,nfft);
l=length(YC);
M=length(Y);
M1=1;
sc=l/(2*N);
Yd=YC(M1+fix(M1/2)+sc:sc:M1+fix(M1/2)+l/2);
g(1:N,1)=(1:N)'*pi/N/T;
g(1:N,2)=20*log10(abs(Yd));
g(1:N,3)=-180*phase((Yd)')'/pi;
%sis=Gd;

w=(1:N)'*pi/N/T;
rm=20*log10(abs(Yd./Ud));
f=-180*phase((Yd./Ud)')'/pi;

%% 
% Bode
[rmbode,fbode,wb] = bode(Gd);
for i=1:length(rmbode)
    rmb(i)=20*log10(rmbode(1,1,i));
    fb(i)=fbode(1,1,i);
end
%% Resultados
subplot(2,1,1);
semilogx(w,rm,wb,rmb);
grid;legend('ri','riirb')
axis([.01 10 -20 30]);
subplot(2,1,2);
semilogx(w,f,wb,fb);
grid;legend('ri','riirb')
axis([.01 10 -300 0]);
