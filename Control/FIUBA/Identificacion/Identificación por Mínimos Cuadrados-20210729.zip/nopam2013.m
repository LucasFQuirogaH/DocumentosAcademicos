%% Respuesta Impulsional por Correlaci�n
% 
%% Planta
n=1000;
A=[1 -1.5 .7]; B=[0 1 .5]; C=[1]; F=[1]; D=[1];
th=idpoly(A,B,C,D,F,1,1);
e=.1*randn(n,1);
m=20;
ui=zeros(n,1);
ui(1)=1;
ri=idsim(ui,th);
rii=idsim([ui e],th);
% Excitaci�n Escal�n
ues=ones(n,1);
z=[ues e];
yes=idsim(z,th);
rie=[0; yes(2:m+1)-yes(1:m)];
%% Resultados
plot([ri(1:m) rii(1:m) rie(1:m)]);grid;legend('ri','rii','rie')



%% Ejemplo 2. Respuesta Impulsional por Correlaci�n
urb=sign(randn(n,1));
z=[urb e];
yrb=idsim(z,th);
zrb=[yrb urb];
M=19;
R=covf(zrb,M+1);
Ryy=[R(1,m:-1:2)';R(1,:)'];
Ruu=[R(4,m:-1:2)';R(4,:)'];
vuu=Ruu(m);
vyu=sqrt(Ryy(m)*vuu);
%r(:,1)=[-m+1:1:m-1]';
Ryu=[R(3,m:-1:2)';R(2,:)']/vyu;
rirb=Ryu(m:2*m-1)*vyu/vuu;
% o m�s simple,
rirb=R(2,:)'/R(4,1);
%% Resultados
plot([ri(1:m) rirb]);grid;legend('ri','riirb')


%% Respuesta en Frecuencia con Excitaci�n Ruido Blanco
T=1;
N=128;
M=[];
nfft = 2^nextpow2(max(n,2*N));
FY=fft(rirb,nfft); %FFT de la correlaci�n cruzada
l=length(FY);
M=length(FY);
M1=1;
sc=l/(2*N);
FYd=FY(M1+fix(M1/2)+sc:sc:M1+fix(M1/2)+l/2);

sis=tf(B,A,T);

w=(1:N)'*pi/N/T;
rm=20*log10(abs(FYd));
f=-180*phase((FYd)')'/pi;
%% 
% Bode
[rmbode,fbode,wb] = bode(sis);
for i=1:length(rmbode)
    rmb(i)=20*log10(rmbode(1,1,i));
    fb(i)=fbode(1,1,i);
end
%% Resultados
subplot(2,1,1);
semilogx(w,rm,wb,rmb);
grid;legend('ri','riirb')
axis([.01 10 -20 30]);
subplot(2,1,2);
semilogx(w,f,wb,fb);
grid;legend('ri','riirb')
axis([.01 10 -300 0]);
