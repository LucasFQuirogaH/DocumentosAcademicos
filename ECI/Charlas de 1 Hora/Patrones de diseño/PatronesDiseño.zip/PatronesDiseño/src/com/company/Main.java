package com.company;

import com.company.behavioral.strategy.CapitalStrategyTextFormatter;
import com.company.behavioral.strategy.Context;
import com.company.behavioral.strategy.LowerStrategyTextFormatter;
import com.company.creational.builder.builders.CarBuilder;
import com.company.creational.builder.builders.CarManualBuilder;
import com.company.creational.builder.cars.Car;
import com.company.creational.builder.cars.Manual;
import com.company.creational.builder.director.Director;
import com.company.structural.decorator.*;

public class Main {

    public static void main(String[] args) {

        /* Creational */
        //testBuilder();

        /* Structural */
        //testDecorator();

        /* Behavior */
        testStrategy();

    }

    private static void testBuilder(){
        Director director = new Director();

        /* Build sport car */
        CarBuilder builder = new CarBuilder();
        director.constructSportsCar(builder);
        Car car = builder.getResult();
        System.out.println("\nSport Car built:\n" + car.print());
        /* Build manual car */
        CarManualBuilder manualBuilder = new CarManualBuilder();
        director.constructSUV(manualBuilder);
        Manual carManual = manualBuilder.getResult();
        System.out.println("\nCar manual built:\n" + carManual.print());
    }

    private static void testDecorator(){
        String salaryRecords = "Name,Salary\nJohn Smith,100000\nSteven Jobs,912000";
        DataSourceDecorator encoded = new CompressionDecorator(
                new EncryptionDecorator(new FileDataSource("out/OutputDemo.txt")));
        encoded.writeData(salaryRecords);
        DataSource plain = new FileDataSource("out/OutputDemo.txt");

        System.out.println("- Input ----------------");
        System.out.println(salaryRecords);
        System.out.println("- Encoded --------------");
        System.out.println(plain.readData());
        System.out.println("- Decoded --------------");
        System.out.println(encoded.readData());
    }

    private static void testStrategy(){
        Context context = new Context(new CapitalStrategyTextFormatter());
        context.publishText("Este texto será convertido a MAYUSCULAS a través del algoritmo");

        context = new Context(new LowerStrategyTextFormatter());
        context.publishText("Esto texto SERA CONVERTIDO a MINUSCULAS a través del algortimo");
    }
}
