package com.company.creational.builder.cars;

public enum CarType {
    CITY_CAR, SPORTS_CAR, SUV
}