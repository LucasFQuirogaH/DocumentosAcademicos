package com.company.behavioral.strategy;


public interface StragetyTextFormatter {
    void format(String text);
}
