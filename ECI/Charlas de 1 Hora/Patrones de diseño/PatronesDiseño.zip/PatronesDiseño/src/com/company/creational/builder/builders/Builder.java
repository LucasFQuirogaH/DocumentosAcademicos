package com.company.creational.builder.builders;

import com.company.creational.builder.cars.CarType;
import com.company.creational.builder.features.Engine;
import com.company.creational.builder.features.GPSNavigator;
import com.company.creational.builder.features.Transmission;

public interface Builder {
    void setCarType(CarType type);
    void setSeats(int seats);
    void setEngine(Engine engine);
    void setTransmission(Transmission transmission);
    void setGPSNavigator(GPSNavigator gpsNavigator);
}
